package com.example.book_shop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
