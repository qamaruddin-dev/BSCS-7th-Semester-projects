# Book Store App 

- Preview video: https://www.youtube.com/watch?v=ZPu-udyRgG0
- [My Twitter](https://twitter.com/sangvaleap)

- [My Patreon](https://www.patreon.com/sangvaleap)
- [My Linkedin](https://www.linkedin.com/in/sangvaleap-vanny-353b25aa/)
- [My Upwork](https://www.upwork.com/freelancers/~01482fe63544bbcb48)

- My Email: sangvaleap.vanny@gmail.com
- UI/UX source: https://dribbble.com/shots/11544157-Lifemasto-Online-Book-shop-Screen-Design

=> To access complete source code, please join [My Patreon](https://www.patreon.com/sangvaleap)

<img width="600" alt="Screen Shot 2021-12-16 at 4 23 26 PM" src="https://user-images.githubusercontent.com/86506519/146344460-57df80e1-dce2-4bc3-bffd-ba6034e91f28.png">
<img width="600" alt="Screen Shot 2021-12-16 at 4 23 53 PM" src="https://user-images.githubusercontent.com/86506519/146344479-726201e0-c9a1-4af9-bec9-3956faf87e11.png">
<img width="600" alt="Screen Shot 2021-12-16 at 4 24 16 PM" src="https://user-images.githubusercontent.com/86506519/146344484-f91c6f13-8055-4612-a3cc-bf9cc11bd712.png">
<img width="600" alt="Screen Shot 2021-12-16 at 4 25 38 PM" src="https://user-images.githubusercontent.com/86506519/146344490-4df2f1f0-d940-4af9-b9bf-6972cd9efc02.png">
